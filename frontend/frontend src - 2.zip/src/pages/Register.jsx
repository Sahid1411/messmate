import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import Navbar from '../components/Navbar';

const Register = () => {
    const [formData, setFormData] = useState({ name: '', email: '', password: '', role: 'student', dept: '', roomNo: '' });
    const navigate = useNavigate();

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            await axios.post('http://localhost:5000/api/auth/register', formData);
            alert('Registration Successful! Please Login.');
            navigate('/login');
        } catch (error) {
            alert('Error Registering');
        }
    };

    return (
        <>
            <Navbar />
            <div className="container mt-5 mb-5">
                {/* Added a Row to center the content */}
                <div className="row justify-content-center">
                    {/* RESPONSIVE LOGIC:
                       col-12: Full width on mobile
                       col-md-8: 8/12 width on tablets
                       col-lg-5: 5/12 width on desktops (cleaner look)
                    */}
                    <div className="col-12 col-md-8 col-lg-5">
                        <div className="card p-4 shadow-sm">
                            <h3 className="text-center mb-4">Register</h3>
                            <form onSubmit={handleSubmit}>
                                <div className="mb-3">
                                    <input 
                                        className="form-control" 
                                        placeholder="Name" 
                                        required
                                        onChange={e => setFormData({ ...formData, name: e.target.value })} 
                                    />
                                </div>
                                <div className="mb-3">
                                    <input 
                                        className="form-control" 
                                        type="email"
                                        placeholder="Email" 
                                        required
                                        onChange={e => setFormData({ ...formData, email: e.target.value })} 
                                    />
                                </div>
                                <div className="mb-3">
                                    <input 
                                        className="form-control" 
                                        type="password" 
                                        placeholder="Password" 
                                        required
                                        onChange={e => setFormData({ ...formData, password: e.target.value })} 
                                    />
                                </div>
                                <div className="mb-3">
                                    <select 
                                        className="form-select" 
                                        onChange={e => setFormData({ ...formData, role: e.target.value })}
                                        value={formData.role}
                                    >
                                        <option value="student">Student</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                </div>

                                {/* Row for Dept and Room No: Stack on mobile, Side-by-side on Desktop */}
                                <div className="row">
                                    <div className="col-6 mb-3">
                                        <input 
                                            className="form-control" 
                                            placeholder="Dept" 
                                            onChange={e => setFormData({ ...formData, dept: e.target.value })} 
                                        />
                                    </div>
                                    <div className="col-6 mb-3">
                                        <input 
                                            className="form-control" 
                                            placeholder="Room No" 
                                            onChange={e => setFormData({ ...formData, roomNo: e.target.value })} 
                                        />
                                    </div>
                                </div>

                                <button className="btn btn-success w-100 py-2">Register</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Register;